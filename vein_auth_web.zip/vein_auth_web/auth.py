import os
import time
import subprocess
import numpy as np
import cv2
import psycopg2
import joblib
from cryptography.fernet import Fernet
from skimage.feature import hog
from skimage import exposure
from sklearn.svm import SVC
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
import hashlib
import logging
from typing import Optional, Tuple, List
from config import CONFIG, BASE_DIR

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(CONFIG['capture_dir'], 'vein_auth.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class DatabaseManager:
    """Handles all database operations"""
    
    @staticmethod
    def get_db_connection():
        """Establish database connection"""
        try:
            conn = psycopg2.connect(
                host=CONFIG['db_host'],
                database=CONFIG['db_name'],
                user=CONFIG['db_user'],
                password=CONFIG['db_password'],
                port=CONFIG['db_port']
            )
            conn.set_session(autocommit=False)
            return conn
        except psycopg2.Error as e:
            logger.error(f"Database conranection error: {str(e)}")
            raise

    @staticmethod
    def initialize_database():
        """Initialize database tables"""
        conn = None
        try:
            conn = DatabaseManager.get_db_connection()
            cur = conn.cursor()

            cur.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id SERIAL PRIMARY KEY,
                    username VARCHAR(50) UNIQUE NOT NULL,
                    password_hash VARCHAR(128) NOT NULL,
                    email VARCHAR(100),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            cur.execute("""
                CREATE TABLE IF NOT EXISTS vein_patterns (
                    pattern_id SERIAL PRIMARY KEY,
                    user_id INTEGER REFERENCES users(user_id),
                    pattern_data BYTEA NOT NULL,
                    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            conn.commit()
            logger.info("Database initialized successfully")
        except Exception as e:
            logger.error(f"Database initialization error: {str(e)}")
            raise
        finally:
            if conn:
                conn.close()

    @staticmethod
    def create_user(username: str, password: str, email: Optional[str] = None) -> Optional[int]:
        """Create a new user account"""
        conn = None
        try:
            password_hash = hashlib.sha256(password.encode()).hexdigest()
            conn = DatabaseManager.get_db_connection()
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO users (username, password_hash, email) VALUES (%s, %s, %s) RETURNING user_id",
                (username, password_hash, email))
            user_id = cur.fetchone()[0]
            conn.commit()
            print(f"User {username} created successfully")
            logger.info(f"User {username} created successfully")
            return user_id
        except psycopg2.IntegrityError:
            print(f"Username {username} already exists")
            logger.warning(f"Username {username} already exists")
            return None
        except Exception as e:
            logger.error(f"User creation error: {str(e)}")
            return None
        finally:
            if conn:
                conn.close()

    @staticmethod
    def authenticate_user_db(username: str, password: str) -> Optional[int]:
        """Authenticate user credentials"""
        conn = None
        try:
            password_hash = hashlib.sha256(password.encode()).hexdigest()
            conn = DatabaseManager.get_db_connection()
            cur = conn.cursor()
            cur.execute(
                "SELECT user_id FROM users WHERE username = %s AND password_hash = %s",
                (username, password_hash))
            result = cur.fetchone()
            print(f"the username:{username}, paswword_hash:{password}")
            return result[0] if result else None
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            return None
        finally:
            if conn:
                conn.close()

    @staticmethod
    def check_vein_registered(user_id: int) -> bool:
        """Check if user has registered vein pattern"""
        conn = None
        try:
            conn = DatabaseManager.get_db_connection()
            cur = conn.cursor()
            cur.execute("""
                SELECT 1 FROM vein_patterns 
                WHERE user_id = %s
                LIMIT 1
            """, (user_id,))
            
            return cur.fetchone() is not None
        except psycopg2.Error as e:
            logger.error(f"Database error in check_vein_registered: {e.pgerror}")
            return False
        finally:
            if conn:
                conn.close()

    @staticmethod
    def store_vein_pattern(user_id: int, pattern: np.ndarray) -> bool:
        """Store pattern with proper type handling and validation"""
        conn = None
        try:
            # Validate pattern before storage
            if pattern.size == 0:
                raise ValueError("Empty pattern array")
            if np.all(pattern == 0):
                raise ValueError("Pattern contains only zeros")
                
            # Convert to float32 and normalize
            pattern = pattern.astype(np.float32)
            pattern = pattern / (np.linalg.norm(pattern) + 1e-6)
            
            # Serialize and encrypt
            serialized = pattern.tobytes()
            encrypted = VeinAuthManager.encrypt_data(serialized)
            
            conn = DatabaseManager.get_db_connection()
            cur = conn.cursor()
            
            # Delete old pattern if exists
            cur.execute("DELETE FROM vein_patterns WHERE user_id = %s", (user_id,))
            
            # Store new pattern
            cur.execute(
                "INSERT INTO vein_patterns (user_id, pattern_data) VALUES (%s, %s)",
                (user_id, encrypted)
            )
            
            conn.commit()
            return True
            
        except Exception as e:
            logger.error(f"Pattern storage failed: {str(e)}")
            if conn:
                conn.rollback()
            return False
        finally:
            if conn:
                conn.close()

    @staticmethod
    def retrieve_vein_pattern(user_id: int) -> Optional[np.ndarray]:
        """Retrieve and decrypt vein pattern with verification"""
        conn = None
        try:
            conn = DatabaseManager.get_db_connection()
            cur = conn.cursor()
            cur.execute("""
                SELECT pattern_data FROM vein_patterns 
                WHERE user_id = %s 
                ORDER BY last_updated DESC 
                LIMIT 1
            """, (user_id,))
            result = cur.fetchone()
            
            if not result:
                logger.warning(f"No pattern found for user {user_id}")
                return None
                
            encrypted_data = bytes(result[0])
            decrypted = VeinAuthManager.decrypt_data(encrypted_data)
            pattern = np.frombuffer(decrypted, dtype=np.float32)
            print(f"the pattern value : {pattern}")
            
            if pattern.size == 0:
                raise ValueError("Empty pattern retrieved")
            if np.all(pattern == 0):
                logger.warning("Retrieved pattern contains all zeros")
                
            return pattern
            
        except Exception as e:
            logger.error(f"Retrieval error for user {user_id}: {str(e)}")
            return None
        finally:
            if conn:
                conn.close()

    @staticmethod
    def add_training_sample(user_id: int, image: np.ndarray) -> bool:
        """Store successful authentication samples for retraining"""
        conn = None
        try:
            features = VeinAuthManager.preprocess_image(image)
            
            # Create training_samples table if not exists
            conn = DatabaseManager.get_db_connection()
            cur = conn.cursor()
            
            cur.execute("""
                CREATE TABLE IF NOT EXISTS training_samples (
                    sample_id SERIAL PRIMARY KEY,
                    user_id INTEGER REFERENCES users(user_id),
                    features BYTEA NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Store the features
            encrypted = VeinAuthManager.encrypt_data(features.tobytes())
            cur.execute(
                "INSERT INTO training_samples (user_id, features) VALUES (%s, %s)",
                (user_id, encrypted)
            )
            
            conn.commit()
            
            # Check if we have enough samples to retrain
            cur.execute("""
                SELECT COUNT(*) FROM training_samples 
                WHERE user_id = %s
            """, (user_id,))
            count = cur.fetchone()[0]
            
            if count >= 10:  # Retrain after collecting 10 new samples
                VeinAuthManager.retrain_model(user_id)
                
            return True
            
        except Exception as e:
            logger.error(f"Error adding training sample: {str(e)}")
            if conn:
                conn.rollback()
            return False
        finally:
            if conn:
                conn.close()

class VeinAuthManager:
    """Handles vein authentication operations with improved HOG + SVM approach"""
    
    @staticmethod
    def generate_key() -> None:
        """Generate encryption key if not exists"""
        if not os.path.exists(CONFIG['key_path']):
            key = Fernet.generate_key()
            with open(CONFIG['key_path'], 'wb') as f:
                f.write(key)
            logger.info("Generated new encryption key")

    @staticmethod
    def encrypt_data(data: bytes) -> bytes:
        """Encrypt data"""
        if not os.path.exists(CONFIG['key_path']):
            raise FileNotFoundError("Encryption key not found")
        
        key = open(CONFIG['key_path'], 'rb').read()
        cipher = Fernet(key)
        return cipher.encrypt(data)

    @staticmethod
    def decrypt_data(encrypted_data: bytes) -> bytes:
        """Decrypt data"""
        if not os.path.exists(CONFIG['key_path']):
            raise FileNotFoundError("Encryption key not found")
        
        key = open(CONFIG['key_path'], 'rb').read()
        cipher = Fernet(key)
        return cipher.decrypt(encrypted_data)

    @staticmethod
    def capture_finger_image() -> Optional[np.ndarray]:
        """Capture finger vein image using libcamera and return grayscale image array"""
        try:
            temp_path = os.path.join(CONFIG['capture_dir'], 'temp.jpg')
            cmd = f"libcamera-jpeg -o {temp_path} {CONFIG['libcamera_params']}"
            subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)

            img = cv2.imread(temp_path)
            if img is None:
                raise ValueError("Failed to read captured image")

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            os.remove(temp_path)
            return gray
        except Exception as e:
            logger.error(f"Capture error: {str(e)}")
            return None

    @staticmethod
    def preprocess_image(img: np.ndarray) -> np.ndarray:
        """Process image with input validation"""
        if not isinstance(img, np.ndarray):
            raise TypeError(f"Expected numpy array, got {type(img)}")
        if len(img.shape) not in (2, 3):
            raise ValueError(f"Invalid image shape: {img.shape}")
        """Improved image processing with robust feature extraction"""
        try:
            # 1. Convert to grayscale if needed
            if len(img.shape) > 2:
                img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            
            # 2. Adaptive histogram equalization
            clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
            equalized = clahe.apply(img)
            
            # 3. Noise reduction
            denoised = cv2.fastNlMeansDenoising(equalized, h=10)
            
            # 4. Edge enhancement
            blurred = cv2.GaussianBlur(denoised, (5,5), 0)
            edges = cv2.Canny(blurred, 50, 150)
            
            # 5. Combine original and edge features
            combined = cv2.addWeighted(denoised, 0.7, edges, 0.3, 0)
            
            # 6. Robust HOG feature extraction
            hog_features = hog(
            denoised,
            orientations=9,
            pixels_per_cell=(8,8),
            cells_per_block=(2,2),
            visualize=False
            )
            
            # Ensure 1D array output
            return hog_features.flatten() 
            
            # 7. Normalize features
            features = features / (np.linalg.norm(features) + 1e-6)
            
            return features
            
        except Exception as e:
            logger.error(f"Processing error: {str(e)}")
            raise

    @staticmethod
    def train_model(user_id: int) -> SVC:
        """Improved model training with realistic synthetic samples"""
        try:
            stored = DatabaseManager.retrieve_vein_pattern(user_id)
            if stored is None:
                raise ValueError("No stored pattern found for user")
            
            # Create realistic training samples
            samples = []
            labels = []
            
            # 1. Add original sample
            samples.append(stored)
            labels.append(1)
            
            # 2. Add brightness variations
            for alpha in [0.9, 1.1]:
                samples.append(stored * alpha)
                labels.append(1)
            
            # 3. Add small random noise
            for _ in range(3):
                samples.append(stored + np.random.normal(0, 0.05, stored.shape))
                labels.append(1)
            
            # 4. Add realistic impostor samples
            for _ in range(5):
                impostor = np.roll(stored, np.random.randint(10,50))
                impostor = impostor * np.random.uniform(0.8, 1.2)
                samples.append(impostor)
                labels.append(0)
            
            X_train = np.array(samples)
            y_train = np.array(labels)
            
            # Robust classifier pipeline
            model = make_pipeline(
                StandardScaler(),
                SVC(
                    kernel='rbf',
                    C=1.0,
                    gamma='scale',
                    probability=True,
                    class_weight='balanced'
                )
            )
            
            model.fit(X_train, y_train)
            
            # Save per-user model
            model_path = str(BASE_DIR / f'svm_model_{user_id}.pkl')
            joblib.dump(model, model_path)
            
            logger.info(f"Model trained and saved to {model_path}")
            return model
            
        except Exception as e:
            logger.error(f"Model training failed: {str(e)}")
            raise
    
    @staticmethod
    def authenticate_user(user_id: int, live_image: np.ndarray) -> Tuple[bool, float]:
        try:
            # 1. Process image with enhanced feature extraction
            live_features = VeinAuthManager.preprocess_image(live_image)
            if live_features is None or live_features.ndim != 1:
                raise ValueError("Invalid feature dimensions")
            
            # 2. Applying additional normalization
            live_features = live_features / (np.linalg.norm(live_features) + 1e-6)
            
            # 3. Force fresh model load (no caching)
            model_path = str(BASE_DIR / f'svm_model_{user_id}.pkl')
            if not os.path.exists(model_path):
                raise FileNotFoundError(f"Model for user {user_id} not found")
                
            model = joblib.load(model_path)
            
            # 4. Get updated prediction with debug info
            proba = model.predict_proba(live_features.reshape(1, -1))
            confidence = float(proba[0, 1])
            
            print(f"Raw features mean: {np.mean(live_features):.4f}")
            print(f"Feature variance: {np.var(live_features):.4f}") 
            print(f"New confidence: {confidence:.6f}")
            
            return confidence > CONFIG['auth_threshold'], confidence
            
        except Exception as e:
            logger.error(f"Auth error: {str(e)}")
            return False, 0.0

    @staticmethod
    def retrain_model(user_id: int) -> bool:
        """Retrain model with original + new samples"""
        try:
            # Get original pattern
            original = DatabaseManager.retrieve_vein_pattern(user_id)
            if original is None:
                raise ValueError("No original pattern found")
            
            # Get training samples
            conn = DatabaseManager.get_db_connection()
            cur = conn.cursor()
            cur.execute("""
                SELECT features FROM training_samples
                WHERE user_id = %s
                ORDER BY created_at DESC
                LIMIT 50  # Maximum samples to use
            """, (user_id,))
            
            samples = [original]
            for result in cur.fetchall():
                decrypted = VeinAuthManager.decrypt_data(bytes(result[0]))
                samples.append(np.frombuffer(decrypted, dtype=np.float32))
            
            # Train new model
            X_train = np.array(samples)
            y_train = np.ones(len(samples))  # All genuine samples
            
            # Add synthetic impostor samples
            for _ in range(len(samples)):
                impostor = np.roll(original, np.random.randint(10,50))
                X_train = np.append(X_train, [impostor], axis=0)
                y_train = np.append(y_train, 0)
            
            model = make_pipeline(
                StandardScaler(),
                SVC(kernel='rbf', probability=True, class_weight='balanced')
            )
            model.fit(X_train, y_train)
            
            # Save model
            model_path = str(BASE_DIR / f'svm_model_{user_id}.pkl')
            joblib.dump(model, model_path)
            
            # Clear used training samples
            cur.execute("""
                DELETE FROM training_samples
                WHERE user_id = %s
            """, (user_id,))
            conn.commit()
            
            return True
            
        except Exception as e:
            logger.error(f"Retraining failed: {str(e)}")
            return False
        finally:
            if conn:
                conn.close()