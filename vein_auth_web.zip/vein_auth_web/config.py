import os
from pathlib import Path

# Base directory
BASE_DIR = Path(__file__).parent

# Configuration
CONFIG = {
    'db_name': "your_db_name",
    'db_user': "your_user_name",
    'db_password': "your_password",
    'db_host': "your_host",
    'db_port': "your_port",
    'model_path': str(BASE_DIR / "pca_model.pkl"),
    'key_path': str(BASE_DIR / "encryption.key"),
    'capture_dir': str(BASE_DIR / "captures"),
    'libcamera_params': "--width 1280 --height 720 --nopreview --timeout 2000",
    'min_samples': 5,
    'max_samples': 7,
    'auth_threshold': 0.65,
    'max_distance': 5.0,
    'secret_key': 'your_secret_key',#For Flask Sessions
    'upload_folder': str(BASE_DIR / "uploads")
}

# Ensuring required directories exist
os.makedirs(CONFIG['capture_dir'], exist_ok=True)
os.makedirs(CONFIG['upload_folder'], exist_ok=True)