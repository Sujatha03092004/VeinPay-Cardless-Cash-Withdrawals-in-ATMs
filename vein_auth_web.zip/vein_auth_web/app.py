from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.utils import secure_filename
import os
from auth import DatabaseManager, VeinAuthManager
from config import CONFIG, BASE_DIR
import time
import cv2
import numpy as np
import base64
import re
import requests
import subprocess
from flask import Response
import glob  # Add this with other imports
import logging  # Add this if not already present

app = Flask(__name__)
app.secret_key = CONFIG['secret_key']
app.config['UPLOAD_FOLDER'] = CONFIG['upload_folder']
print("The app folder is created")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('vein_auth.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Initialize system
VeinAuthManager.generate_key()
DatabaseManager.initialize_database()

# Helper function to save base64 image
def save_base64_image(data_url: str, user_id: int, prefix: str = "sample") -> str:
    """Save base64 image and return the decoded numpy array"""
    try:
        # Extract the base64 data from the Data URL
        header, data = data_url.split(',', 1)
        img_data = base64.b64decode(data)
        
        # Convert to numpy array
        nparr = np.frombuffer(img_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)
        
        if img is None:
            raise ValueError("Failed to decode image")
            
        # Generate filename and save
        filename = f"{prefix}_{user_id}_{int(time.time())}.jpg"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        cv2.imwrite(filepath, img)
        
        return filepath
    except Exception as e:
        logger.error(f"Error saving base64 image: {str(e)}")
        raise

@app.route('/')
def home():
    if 'user_id' in session:
        return redirect(url_for('main'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user_id = DatabaseManager.authenticate_user_db(username, password)
        if user_id:
            session['user_id'] = user_id
            session['username'] = username
            return redirect(url_for('main'))
        else:
            flash('Invalid username or password', 'error')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        email = request.form.get('email', None)
        
        if password != confirm_password:
            flash('Passwords do not match', 'error')
        else:
            user_id = DatabaseManager.create_user(username, password, email)
            if user_id:
                session['user_id'] = user_id
                session['username'] = username
                flash('Account created successfully!', 'success')
                return redirect(url_for('main'))
            else:
                flash('Username already exists', 'error')
    return render_template('signup.html')

@app.route('/capture')
def capture():
    try:
        # Define a temporary filename
        image_path = '/tmp/capture.jpg'

        # Run libcamera-still to capture the image
        result = subprocess.run(
            ['libcamera-still', '-o', image_path, '--immediate', '-n'],
            capture_output=True
        )

        if result.returncode != 0:
            return f"Libcamera capture failed: {result.stderr.decode()}", 500

        # Read the image file
        with open(image_path, 'rb') as img_file:
            img_data = img_file.read()

        return Response(img_data, mimetype='image/jpeg')

    except Exception as e:
        return f"Error: {str(e)}", 500

# Add this new endpoint to your existing app.py
@app.route('/capture_image')
def capture_image():
    try:
        # Make request to our camera service
        response = requests.get('http://localhost:5000/capture')
        
        if response.status_code != 200:
            return jsonify({"success": False, "error": "Camera capture failed"})
            
        # Convert the image to base64
        img_data = base64.b64encode(response.content).decode('utf-8')
        return jsonify({
            "success": True,
            "image": f"data:image/jpeg;base64,{img_data}"
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route('/process_sample', methods=['POST'])
def process_sample():
    if 'user_id' not in session:
        return jsonify({'success': False, 'error': 'Not authenticated'})
    
    try:
        data = request.json
        image_data = data['image']
        sample_num = data['sample_number']
        
        # Save and get the image path
        filepath = save_base64_image(image_data, session['user_id'], f"reg_{sample_num}")
        
        # Process the image
        img = cv2.imread(filepath, cv2.IMREAD_GRAYSCALE)
        if img is None:
            raise ValueError("Failed to read saved image")
            
        features = VeinAuthManager.preprocess_image(img)
        
        # Save features to temporary storage
        temp_path = filepath.replace('.jpg', '.npy')
        np.save(temp_path, features)
        
        return jsonify({
            'success': True, 
            'filepath': filepath,
            'features_path': temp_path
        })
    
    except Exception as e:
        logger.error(f"Error processing sample: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/finalize_registration', methods=['POST'])
def finalize_registration():
    if 'user_id' not in session:
        return jsonify({'success': False, 'error': 'Not authenticated'})
    
    try:
        user_id = session['user_id']
        samples = []
        
        # Load all saved feature files
        for i in range(1, 6):  # For 5 samples
            pattern = f"reg_{i}_{user_id}_*.npy"
            files = glob.glob(os.path.join(app.config['UPLOAD_FOLDER'], pattern))
            
            if not files:
                logger.warning(f"No feature file found for sample {i}")
                continue
                
            latest_file = max(files, key=os.path.getmtime)
            try:
                features = np.load(latest_file)
                samples.append(features)
                logger.info(f"Successfully loaded features from {latest_file}")
            except Exception as e:
                logger.error(f"Error loading features from {latest_file}: {str(e)}")
        
        if len(samples) >= 2:  # Require at least 2 good samples
            avg_pattern = np.mean(samples, axis=0)
            
            if DatabaseManager.store_vein_pattern(user_id, avg_pattern):
                VeinAuthManager.train_model(user_id)
                
                # Clean up files
                for f in glob.glob(os.path.join(app.config['UPLOAD_FOLDER'], f"reg_*_{user_id}_*")):
                    try:
                        os.remove(f)
                        logger.info(f"Cleaned up file: {f}")
                    except Exception as e:
                        logger.error(f"Error cleaning up file {f}: {str(e)}")
                
                return jsonify({'success': True})
        
        return jsonify({
            'success': False, 
            'error': f'Not enough valid samples (have {len(samples)}, need at least 2)'
        })
    
    except Exception as e:
        logger.error(f"Finalization error: {str(e)}")
        return jsonify({
            'success': False, 
            'error': f'Registration failed: {str(e)}'
        }), 500

@app.route('/main')
def main():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    vein_registered = DatabaseManager.check_vein_registered(session['user_id'])
    return render_template('main.html', 
                         username=session.get('username', 'User'),
                         vein_registered=vein_registered)

@app.route('/register', methods=['GET'])
def register():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/authenticate', methods=['POST'])
def authenticate_api():
    if 'user_id' not in session:
        return jsonify({'success': False, 'error': 'Not authenticated'})
    
    try:
        data = request.json
        image_data = data['image']
        
        # Decode base64 image
        header, encoded = image_data.split(',', 1)
        binary_data = base64.b64decode(encoded)
        nparr = np.frombuffer(binary_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)
        
        if img is None:
            raise ValueError("Failed to decode image")
        
        # Process and authenticate
        authenticated, confidence = VeinAuthManager.authenticate_user(
            session['user_id'], img)

        # Store high-confidence samples for retraining
        if authenticated and confidence > 0.7:  # Only store high-confidence samples
            try:
                DatabaseManager.add_training_sample(session['user_id'], img)
                logger.info(f"Stored training sample for user {session['user_id']}")
            except Exception as e:
                logger.error(f"Failed to store training sample: {str(e)}")

        return jsonify({
            'success': True,
            'authenticated': bool(authenticated),
            'confidence': float(confidence)
        })
    
    except Exception as e:
        logger.error(f"Authentication error: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        })
        
@app.route('/authenticate', methods=['GET'])
def authenticate():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if not DatabaseManager.check_vein_registered(session['user_id']):
        flash('You need to register your vein pattern first', 'error')
        return redirect(url_for('register'))
    
    return render_template('authenticate.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(host='0.0.0.0', port=5000, debug=True)