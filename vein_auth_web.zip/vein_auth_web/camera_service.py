import subprocess
import time
from flask import Flask, jsonify
import os

app = Flask(__name__)
CAPTURE_DIR = "/tmp/camera_captures"
os.makedirs(CAPTURE_DIR, exist_ok=True)

def check_camera():
    try:
        result = subprocess.run(["libcamera-hello", "--list-cameras"], 
                              capture_output=True, text=True)
        return "Available" in result.stdout
    except:
        return False

@app.route('/capture')
def capture_image():
    if not check_camera():
        return jsonify({"success": False, "error": "Camera not detected"})
    
    filename = f"{int(time.time())}.jpg"
    filepath = os.path.join(CAPTURE_DIR, filename)
    
    try:
        result = subprocess.run([
            "libcamera-jpeg",
            "-o", filepath,
            "--width", "1280",
            "--height", "720",
            "--nopreview",
            "--timeout", "2000",
            "--quality", "90"
        ], capture_output=True, text=True, timeout=10)
        
        if result.returncode != 0:
            return jsonify({
                "success": False,
                "error": f"Capture failed: {result.stderr}"
            })
            
        if not os.path.exists(filepath):
            return jsonify({
                "success": False,
                "error": "No image file created"
            })
            
        return jsonify({
            "success": True,
            "filepath": filepath
        })
        
    except subprocess.TimeoutExpired:
        return jsonify({
            "success": False,
            "error": "Camera timeout"
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)