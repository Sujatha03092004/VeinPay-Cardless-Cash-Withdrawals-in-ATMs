// Global variables
let currentSample = 0;
let totalSamples = 3; // Minimum samples required
let capturedSamples = [];
let cameraStatusElement = document.getElementById('camera-status-text');

// DOM Ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize components based on current page
    if (document.getElementById('capture-form')) {
        initRegistrationPage();
    }
    
    if (document.getElementById('auth-form')) {
        initAuthenticationPage();
    }
    
    // Initialize camera status
    updateCameraStatus();
});

// Registration Page Functions
function initRegistrationPage() {
    const captureBtn = document.getElementById('capture-btn');
    const doneBtn = document.getElementById('done-btn');
    const progressBar = document.getElementById('progress');
    const progressText = document.getElementById('progress-text');
    
    // Handle capture button click
    captureBtn.addEventListener('click', async function() {
        try {
            captureBtn.disabled = true;
            updateCameraStatus("Capturing...");
            
            // Capture image from Pi Camera
            const imageData = await captureFromPiCamera();
            
            // Add to captured samples
            capturedSamples.push(imageData);
            currentSample++;
            
            // Update progress
            updateProgress();
            
            // Show captured sample
            showCapturedSample(imageData);
            
            // If we have enough samples, show done button
            if (currentSample >= totalSamples) {
                captureBtn.classList.add('hidden');
                doneBtn.classList.remove('hidden');
            }
            
            updateCameraStatus("Ready");
        } catch (error) {
            console.error("Capture error:", error);
            showToast("Capture failed: " + error.message, 'error');
            updateCameraStatus("Error: " + error.message);
        } finally {
            captureBtn.disabled = false;
        }
    });
    
    // Handle done button click
    doneBtn.addEventListener('click', async function() {
        try {
            doneBtn.disabled = true;
            doneBtn.textContent = 'Processing...';
            
            // Send all samples to server
            for (let i = 0; i < capturedSamples.length; i++) {
                await processSample(capturedSamples[i], i+1);
            }
            
            // Finalize registration
            const response = await fetch('/finalize_registration', {
                method: 'POST'
            });
            
            if (response.ok) {
                showToast("Registration successful!", 'success');
                window.location.href = '/main';
            } else {
                throw new Error('Registration failed');
            }
        } catch (error) {
            console.error("Registration error:", error);
            showToast("Registration failed: " + error.message, 'error');
        } finally {
            doneBtn.disabled = false;
            doneBtn.textContent = 'Complete Registration';
        }
    });
}

// Authentication Page Functions
function initAuthenticationPage() {
    const authBtn = document.getElementById('auth-btn');
    const resultContainer = document.getElementById('result-container');
    const authResult = document.getElementById('auth-result');
    const confidence = document.getElementById('confidence');
    
    // Handle authentication button click
    authBtn.addEventListener('click', async function() {
        try {
            authBtn.disabled = true;
            authBtn.textContent = 'Capturing...';
            updateCameraStatus("Capturing...");
            
            // Show processing message
            resultContainer.classList.remove('hidden');
            authResult.textContent = 'Capturing image...';
            authResult.className = '';
            confidence.textContent = '';
            
            // Capture image from Pi Camera
            const imageData = await captureFromPiCamera();
            
            // Show preview
            const img = document.createElement('img');
            img.src = imageData;
            img.style.maxWidth = '300px';
            document.getElementById('auth-preview').innerHTML = '';
            document.getElementById('auth-preview').appendChild(img);
            
            authResult.textContent = 'Processing...';
            
            // Send to server for authentication
            const response = await fetch('/authenticate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    image: imageData
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                if (data.authenticated) {
                    authResult.textContent = 'ACCESS GRANTED';
                    authResult.className = 'success';
                    showToast("Authentication successful!", 'success');
                } else {
                    authResult.textContent = 'ACCESS DENIED';
                    authResult.className = 'error';
                    showToast("Authentication failed", 'error');
                }
                confidence.textContent = `Confidence: ${(data.confidence * 100).toFixed(2)}%`;
            } else {
                throw new Error(data.error || 'Authentication failed');
            }
            
            updateCameraStatus("Ready");
        } catch (error) {
            console.error('Authentication error:', error);
            authResult.textContent = 'Error: ' + error.message;
            authResult.className = 'error';
            confidence.textContent = '';
            showToast("Authentication error: " + error.message, 'error');
            updateCameraStatus("Error: " + error.message);
        } finally {
            authBtn.disabled = false;
            authBtn.textContent = 'Authenticate';
        }
    });
}

// Camera Functions
async function captureFromPiCamera() {
    try {
        const response = await fetch('/capture_image');
        if (!response.ok) {
            throw new Error(`Camera service error: ${response.status}`);
        }
        
        const data = await response.json();
        if (!data.success) {
            throw new Error(data.error || 'Camera capture failed');
        }
        
        return data.image;
    } catch (error) {
        console.error("Camera capture error:", error);
        throw error;
    }
}

async function processSample(imageData, sampleNum) {
    try {
        const response = await fetch('/process_sample', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                image: imageData,
                sample_number: sampleNum
            })
        });
        
        if (!response.ok) {
            throw new Error('Failed to process sample');
        }
    } catch (error) {
        console.error("Sample processing error:", error);
        throw error;
    }
}

// UI Update Functions
function updateProgress() {
    const progressPercent = (currentSample / totalSamples) * 100;
    document.getElementById('progress').style.width = `${progressPercent}%`;
    document.getElementById('progress-text').textContent = 
        `${currentSample}/${totalSamples} samples captured`;
}

function showCapturedSample(imageData) {
    const sampleDiv = document.createElement('div');
    sampleDiv.className = 'sample-thumbnail';
    
    const img = document.createElement('img');
    img.src = imageData;
    img.style.maxWidth = '150px';
    img.style.margin = '5px';
    
    sampleDiv.appendChild(img);
    document.getElementById('samples-preview').appendChild(sampleDiv);
}

function updateCameraStatus(message, isError = false) {
    if (!cameraStatusElement) return;
    
    cameraStatusElement.textContent = message;
    cameraStatusElement.style.color = isError ? 'red' : 'inherit';
}

// Helper Functions
function previewImage(file, elementId) {
    const reader = new FileReader();
    reader.onload = function(event) {
        const img = document.createElement('img');
        img.src = event.target.result;
        img.style.maxWidth = '100%';
        img.style.maxHeight = '300px';
        img.style.borderRadius = '8px';
        document.getElementById(elementId).innerHTML = '';
        document.getElementById(elementId).appendChild(img);
    };
    reader.readAsDataURL(file);
}

// Toast Notification System
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}